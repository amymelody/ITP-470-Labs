#include <stdafx.h>

int TCPSocket::Connect( const SocketAddress& inSocketAddr )
{
	int err = connect( mSocket, inSocketAddr.GetAsSockAddr(), sizeof( sockaddr_in ) );
	if( err != 0 )
	{
		TCPSocketUtil::ReportError( L"TCPSocket::Connect" );
	}

	return err;
}

int TCPSocket::Send( const char* inData, int inLength )
{
	int byteSentCount = send( mSocket, inData, inLength, 0 );
	if( byteSentCount >= 0 )
	{
		return byteSentCount;
	}
	else
	{
		//let's report any other error- don't want to deal with blocking on writing yet
		TCPSocketUtil::ReportError( L"TCPSocket::Send" );
		return -TCPSocketUtil::GetLastError();
	}
}

int TCPSocket::Receive( char* outData, int inMaxLength )
{
	int bytesReceivedCount = recv( mSocket, outData, inMaxLength, 0 );
	if( bytesReceivedCount >= 0 )
	{
		return bytesReceivedCount;
	}
	else
	{
		int error = TCPSocketUtil::GetLastError();
		if( error == WSAEWOULDBLOCK )
		{
			return 0;
		}
		else
		{
			TCPSocketUtil::ReportError( L"TCPSocket::Recv" );
			return -error;
		}
	}
}


int TCPSocket::SetNonBlockingMode( bool inShouldBeNonBlocking )
{
	u_long arg = inShouldBeNonBlocking ? 1 : 0;
	int result = ioctlsocket( mSocket, FIONBIO, &arg );
	if( result == SOCKET_ERROR )
	{
		TCPSocketUtil::ReportError( L"TCPSocketUtil::SetNonBlockingMode" );
		return TCPSocketUtil::GetLastError(); 
	}
	else
	{
		return NO_ERROR;
	}
}


TCPSocket::~TCPSocket()
{
	closesocket( mSocket );
}