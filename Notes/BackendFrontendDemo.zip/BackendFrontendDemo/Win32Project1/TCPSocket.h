class TCPSocket
{
public:

	friend class TCPSocketUtil;

	~TCPSocket();

	int Connect( const SocketAddress& inSocketAddr );
	int Send( const char* inData, int inLength );
	int Receive( char* outData, int inBufferSize );

	int SetNonBlockingMode( bool inShouldBeNonBlocking );

private:
	TCPSocket( SOCKET inSocket ) : mSocket( inSocket ) {}

	SOCKET mSocket;

};

typedef shared_ptr< TCPSocket >	TCPSocketPtr;