#include <stdafx.h>
#include <ws2tcpip.h>


bool TCPSocketUtil::StaticInit()
{
	WSADATA wsaData;
	int iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if ( iResult != NO_ERROR ) 
	{
        ReportError (L"Starting Up");
		return false;
    }

	return true;
}

void TCPSocketUtil::CleanUp()
{
	WSACleanup();
}


void TCPSocketUtil::ReportError( const wchar_t* inOperationDesc )
{
	LPVOID lpMsgBuf;
    DWORD errorNum = GetLastError(); 

    FormatMessage(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | 
        FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        errorNum,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPTSTR) &lpMsgBuf,
        0, NULL );


	LOG( L"Error %ls: %d- %ls", inOperationDesc, errorNum, lpMsgBuf );
}

int TCPSocketUtil::GetLastError() 
{ 
	return WSAGetLastError(); 
}

TCPSocketPtr TCPSocketUtil::CreateSocket( uint16_t inPort )
{
	SOCKET s = socket( AF_INET, SOCK_STREAM, IPPROTO_TCP );
	if( s == INVALID_SOCKET )
	{
		ReportError( L"Creating Socket" );
		return TCPSocketPtr();
	}

	
	SocketAddress ownAddress( INADDR_ANY, inPort );
	int bindResult = bind( s, ownAddress.GetAsSockAddr(), ownAddress.GetSize() );
	if( bindResult == SOCKET_ERROR )
	{
		ReportError( L"Binding" );
		return TCPSocketPtr();
	}
	

	//we got this far? we did it!
	return TCPSocketPtr( new TCPSocket( s ) );
}

void TCPSocketUtil::GetAddressFromName( const char* inName, const char* inPort, SocketAddress& outSockAddr )
{
	addrinfo* addrInfo;

	getaddrinfo( inName, inPort, nullptr, &addrInfo );

	if( addrInfo->ai_addr )
	{
		*outSockAddr.GetAsSockAddr() = *addrInfo->ai_addr;
	}

	freeaddrinfo( addrInfo );

	
}


