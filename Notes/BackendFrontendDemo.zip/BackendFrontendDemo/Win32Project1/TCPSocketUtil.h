class TCPSocketUtil
{
public:

	static bool StaticInit();
	static void CleanUp();
	static void ReportError( const wchar_t* inOperationDesc );
	static int GetLastError();
	static TCPSocketPtr CreateSocket( uint16_t inPort );

	static void GetAddressFromName( const char* inName, const char* inPort, SocketAddress& outSockAddr );

};