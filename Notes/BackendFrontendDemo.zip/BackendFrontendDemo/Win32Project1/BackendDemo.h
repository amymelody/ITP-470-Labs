class BackendDemo
{
public:

	static unique_ptr< BackendDemo >	sInstance;
	static void StaticInit( HWND inHWnd );

	~BackendDemo();

	void Update();
	void Paint();

private:


		BackendDemo( HWND inHWnd );

		TCPSocketPtr	mTCPSocket;
		string			mResponseString;

		HWND			mHWnd;

};