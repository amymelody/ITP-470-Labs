#include <stdafx.h>

unique_ptr< BackendDemo >	BackendDemo::sInstance;


void BackendDemo::StaticInit( HWND inHWnd )
{
	sInstance.reset( new BackendDemo( inHWnd ) );
}


BackendDemo::BackendDemo( HWND inHWnd ) :
	mHWnd( inHWnd )
{
	//this is a very simple proof of concept demo to make just one query
	//ideally you'd want to either queue your queries or suppoer multiple requests at once
	//you should probably also abstract the HTTPClient from the demo

	//create a socket that we can use for our requests
	mTCPSocket = TCPSocketUtil::CreateSocket( 0 );

	SocketAddress sockAddr;
	string host = "desolate-shelf-1840.herokuapp.com";
	string port = "3000";
	TCPSocketUtil::GetAddressFromName( host.c_str(), port.c_str(), sockAddr );

	int err = mTCPSocket->Connect( sockAddr );

	//did it work? let's go non blocking now that that's done
	mTCPSocket->SetNonBlockingMode( true );

	//let's try connecting to the 
	//query our webserver for the scores...
	//we have to construct the whole http query here, so let's see what wirehsark does...
	string query = "GET /getScores HTTP/1.1\r\nHost: desolate-shelf-1840.herokuapp.com\r\n\r\n";

	//send!
	mTCPSocket->Send( query.c_str(), query.length() );

	mResponseString = "";

}


BackendDemo::~BackendDemo()
{
	TCPSocketUtil::CleanUp();
}



void BackendDemo::Update()
{
	static char buffer[ 4096 ];

	//try to receive from the socket
	//if we get anything, add it to the reponse...
	int receivedByteCount = mTCPSocket->Receive( buffer, sizeof( buffer ) );
	if( receivedByteCount > 0 )
	{
		mResponseString = mResponseString + string( buffer, receivedByteCount );
		InvalidateRect( mHWnd, NULL, TRUE ); 
	}



}

void BackendDemo::Paint()
{
	if( mResponseString.length() > 0 )
	{
		RECT rect;
		HDC wdc = GetDC( mHWnd );
		SetTextColor(wdc, 0x00000000);
		SetBkMode(wdc,TRANSPARENT);
		rect.left=40;
		rect.top=10;
		rect.right = 400;
		rect.bottom = 800;
		DrawTextA( wdc, mResponseString.c_str(), -1, &rect, DT_NOCLIP  ) ;
		ReleaseDC( mHWnd, wdc);  
	}
		

}